package weather;

import java.lang.Math;
/*
* This class is for Weather Reading interface. 
*/
public class StevensonReading implements WeatherReading {
	
  private double temperature;
  private double dewPoint;
  private double windSpeed;
  private int rain;
  private double relativeHumidity;
  private double heatIndex;
  private double windChill;
	
	public StevensonReading (double temperature, double dewPoint, double windSpeed, int rain) throws IllegalArgumentException{
	
	this.temperature = temperature;
	this.dewPoint = dewPoint;
	this.windSpeed = windSpeed;
	this.rain = rain;
	relativeHumidity = 0;
	heatIndex = 0;
	windChill = 0;
	calculateRelativeHumidity();
	calculateHeatIndex();
	calculateWindChill();
	}
	
	private void calculateRelativeHumidity() {
		double saturatedVaporPressure= 6.11*10*(7.5*temperature/(237.3+temperature));
		double actualVaporPressure= 6.11*10*(7.5*dewPoint/(237.3+dewPoint));
		relativeHumidity= (actualVaporPressure/ saturatedVaporPressure)*100;
	}
	
	private void calculateHeatIndex() {
		final double C1 = -8.78469475556;
		final double C2 = 1.61139411;
		final double C3 = 2.33854883889;
		final double C4 = -0.14611605;
		final double C5 = -0.012308094;
		final double C6 = -0.0164248277778;
		final double C7 = 0.002211732;
		final double C8 = 0.00072546;
		final double C9 = -0.000003582;
		heatIndex = C1 
		+ (C2 * temperature) 
		+ (C3 * relativeHumidity) 
		+ (C4 * temperature * relativeHumidity) 
		+ (C5 * temperature* temperature) 
		+ (C6 * relativeHumidity * relativeHumidity)
		+ (C7 * temperature * temperature * relativeHumidity)
		+ (C8 * temperature * relativeHumidity *  relativeHumidity)
		+ (C9 * temperature * temperature * relativeHumidity * relativeHumidity);
	}
	
	private void calculateWindChill() {
		final double C1 = 35.74;
		final double C2 = 0.6215;
		final double C3 = -35.75;
		final double C4 = 0.4275;
		double temperature = (9.0/5.0) * this.temperature + 32;
		windChill = C1
				+ C2 * temperature
				+ C3 * Math.pow (windSpeed , 0.16)
				+ C4 * temperature * Math.pow (windSpeed , 0.16);
		
	}
	
	
	@Override
	public int getTemperature() {
		// TODO Auto-generated method stub
		return (int)temperature;
	}

	@Override
	public int getDewPoint() {
		// TODO Auto-generated method stub
		return (int)dewPoint;
	}

	@Override
	public int getWindSpeed() {
		// TODO Auto-generated method stub
		return (int)windSpeed;
	}

	@Override
	public int getTotalRain() {
		// TODO Auto-generated method stub
		return rain;
	}

	@Override
	public int getRelativeHumidity() {
		// TODO Auto-generated method stub
		return (int)relativeHumidity;
	}

	@Override
	public int getHeatIndex() {
		// TODO Auto-generated method stub
		return (int)heatIndex;
	}

	@Override
	public int getWindChill() {
		// TODO Auto-generated method stub
		return (int)windChill;
	}
	
	public static void main(String[] args) {
		StevensonReading obj = new StevensonReading(23, 12, 3, 12);
	System.out.println("The Temperature of the reading is: " + obj.getTemperature());
	System.out.println("The Dew Point of the reading is: " + obj.getDewPoint());
	System.out.println("The Wind Speed of the reading is: " + obj.getWindSpeed());
	System.out.println("The Total Rain of the reading is: " + obj.getTotalRain());
	System.out.println("The Relative Humidity of the reading is: " + obj.getRelativeHumidity());
	System.out.println("The Heat Index of the reading is: " + obj.getHeatIndex());
	System.out.println("The Wind Chill of the reading is: " + obj.getWindChill());
  }
}