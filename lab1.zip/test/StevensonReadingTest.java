

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import weather.StevensonReading;
import weather.WeatherReading;

/**
 * This class is going to test Stevenson Reading file.
 */
public class StevensonReadingTest {
  WeatherReading obj;

  @Before
  public void setup() {
    obj = new StevensonReading(23, 12, 3, 12);
  }
  
  @Test
  public void testTemprature() {
    assertEquals(23, obj.getTemperature());
  }
  
  @Test
  public void testDewPoint() {
    assertEquals(12, obj.getDewPoint());
  }
  
  @Test
  public void testWindSpeed() {
    assertEquals(3, obj.getWindSpeed());
  }
  @Test
  public void testTotalRain() {
    assertEquals(12, obj.getTotalRain());
  }
  @Test
  public void testRelativeHumidity() {
	assertEquals(54, obj.getRelativeHumidity());
  }
  @Test
  public void testHeatIndex() {
	assertEquals(24, obj.getHeatIndex());		
  }
  @Test
  public void testWindChill() {
    assertEquals(76, obj.getWindChill());
  }
}